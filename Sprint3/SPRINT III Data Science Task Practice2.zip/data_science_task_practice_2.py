
#TASK - 1
#READING CSV OR EXCEL FILE
#1.Import the 'Salaries.csv' dataset from a specified URL into a Pandas DataFrame named data.
import pandas as pd
url = "https://raw.githubusercontent.com/Apress/data-analysis-and-visualization-using-python/master/Ch07/Salaries.csv"
data = pd.read_csv(url)
print("Salaries.csv - First Few Rows:")
print(data.head())

#2.Import the 'Cars.csv' dataset from a local file path into a Pandas DataFrame named data.
import pandas as pd
file_path = "/content/drive/MyDrive/Cars.xlsx"
data = pd.read_excel(file_path)
print("Cars.csv - First Few Rows:")
print(data.head())


# HEAD
print("\nHEAD of df:")
print(data.head())

# TAIL
print("\nTAIL of df:")
print(data.tail())

# SHAPE
print("\nSHAPE of df:")
print(data.shape)

# DESCRIBE
print("\nDESCRIBE of df:")
print(data.describe())

#TASK - 2
#DICTIONARY:
import pandas as pd

# Step 1
data = {
    'Name': ['John', 'Jane', 'Babu', 'Peter', 'Leju'],
    'Age': [25, 30, 35, 40, 55],
    'City': ['New York', 'London', 'Paris', 'UK', 'Germany']
}
df = pd.DataFrame(data)
print("\nStep 1 - Dictionary:")
print(data)

# Step 2
print("\nDataFrame Creation:")
print(data)

# Step 3
print("\nFirst 5 Rows of df:")
print(df.head())

# Step 4
print("\nInfo Summary of df:")
df.info()

#TASK - 3
#You are working with a dataset of employee salaries, stored in a pandas DataFrame
#named data. The dataset includes the following columns: Department, EmployeeID,
#Salary, YearsOfExperience, and Age. You need to perform the following tasks using the
#groupby() function:


import pandas as pd

# Sample employee dataset for demonstration
data = pd.DataFrame({
    'Department': ['HR', 'IT', 'IT', 'Finance', 'HR', 'Finance'],
    'EmployeeID': [1, 2, 3, 4, 5, 6],
    'Salary': [55000, 70000, 72000, 68000, 60000, 64000],
    'YearsOfExperience': [2, 5, 4, 6, 3, 7],
    'Age': [25, 30, 28, 35, 32, 40]
})

# Task 3.1: Mean salary by department
mean_salary = data.groupby('Department')['Salary'].mean()
print("\nMean Salary by Department:")
print(mean_salary)

# Task 3.2: Group by Department and Age, multiple aggregations
grouped = data.groupby(['Department', 'Age']).agg({
    'Salary': ['mean', 'max'],
    'YearsOfExperience': ['sum', 'mean']
})
print("\nGroup by Department and Age with Multiple Aggregations:")
print(grouped)

# Task 3.3: Filter departments with mean salary > 60000
high_salary = mean_salary[mean_salary > 60000]
print("\nDepartments with Mean Salary > 60000:")
print(high_salary)

# Task 3.4: Custom aggregation function - salary range
def salary_range(series):
    return series.max() - series.min()

custom_agg = data.groupby('Department')['Salary'].agg(salary_range)
print("\nCustom Aggregation (Salary Range) by Department:")
print(custom_agg)