# -*- coding: utf-8 -*-
"""SprintIII_Data_Science_Task_Practice_1.ipynb
#TASK : 1
##PASSING LIST
"""

#1. Convert a given Python list into a NumPy array and display its type.
import numpy as np
List = [1, 2, 3, 4, 5, 6, 7, 8]
array=np.array(List)
print("Array:",array)
print("Type:",type(array))

#2. Convert a given Python nested list (matrix) into a NumPy array and display its properties.
import numpy as np
Nested_List =[[1,2,3],[4,5,6],[7,8,9]]
matrix_array =np.array(Nested_List)
print("Matrix Array:\n", matrix_array)
print("Shape:", matrix_array.shape)
print("Data type:", matrix_array.dtype)

"""#TASK : 2
#OPERATORS
#ARANGE:

"""

#1. Create a NumPy array containing numbers from 1 to 10 using the arange() function
#2. Using NumPy, generate an array of numbers starting from 1 up to 10 (inclusive) with a
#step size of 2 using the arange() function
import numpy as np

arange1=np.arange(1,11)
print("arange(1,10):",arange1)

arange2=np.arange(1,11,2)
print("arange(1,11,2) with step 2",arange2)

"""#ZEROS AND ONES:

"""

#1. Using NumPy, create a 1D array of size 3 filled with zeros using the zeros() function
#2. Create a 10x10 matrix filled with Ones using NumPy
Zeroes_array =np.zeros(3)
print("1D array of size with 3 Zeroes:0",Zeroes_array)

Ones_matrix =np.ones((10,10))
print("10x10 matrix filled with Ones:\n", Ones_matrix)

"""#LINSPACE:

"""

#Using NumPy's linspace() function, generate an array of 25 evenly spaced numbers between 1
#and 11, inclusive.
linspace_array=np.linspace(1,11,25)
print("linspace(1,11,25):",linspace_array)

#IDENTITY MATRIX:
#Using NumPy, create a 10x10 identity matrix where all the elements are zero except for the main
#diagonal, which should contain ones.
import numpy as np
identity_matrix=np.eye(10)
print("10x10 identity matrix:\n", identity_matrix)

#RANDOM PACKAGE:
#Using NumPy, generate a 1D array of length 4 filled with random floating-point numbers
#sampled from a uniform distribution over the interval [0, 1].
import numpy as np
random_array=np.random.rand(4)
print("1D array of length 4 with random floating-point numbers:",random_array)

#RANDN:
#1. Using NumPy, generate a 1D array of length 2 filled with random floating-point numbers
#sampled from a standard normal distribution (mean = 0, standard deviation = 1).

#2. Using NumPy, generate a 6x6 matrix filled with random floating-point numbers sampled from
#a standard normal distribution (mean = 0, standard deviation = 1).

#1
import numpy as np
randn_array = np.random.rand(2)
print("1D array of length 2 with random floating-point numbers:", randn_array)

#2
randn_matrix = np.random.randn(6, 6)
print("6x6 matrix with random floating-point numbers:\n", randn_matrix)

#RANDINT:
#1.Using NumPy, generate a random integer between 1 and 5 (inclusive).
#2.Using NumPy, generate a 1D array of 10 random integers, each ranging from 1 to 5 (inclusive).

#1
import numpy as np
randint_integer = np.random.randint(1,6)
print("Random integer between 1 and 5:", randint_integer)

#2
randint_array = np.random.randint(1, 6, size=10)
print("1D array of 10 random integers between 1 and 5:", randint_array)

"""#ARRAY AND ATTRIBUTES

"""

#ARRAY:
#Using NumPy, create a 1D array containing 25 sequential integers starting from 0.
import numpy as np
array = np.arange(25)
print("1D array containing 25 sequential integers starting from 0:", array)

#RANDOM:
#Using NumPy, generate a 1D array containing 10 random integers ranging from 0 to 49
#(inclusive).
import numpy as np
random_array = np.random.randint(0,50,size=10)
print("1D array containing 10 random integers ranging from 0 to 49:", random_array)

#SHAPE:
#Given a NumPy array a, determine its shape using the appropriate attribute.
import numpy as np
a=np.array([1, 2, 3, 4, 5, 6])
print("Shape of array a:", a.shape)

#RESHAPE:
#Given a NumPy array a, reshape it into a 2x3 matrix
import numpy as np
a=np.array([1, 2, 3, 4, 5, 6])
reshaped_matrix = a.reshape(2, 3)
print("Reshaped matrix:\n", reshaped_matrix)

#MINIMUM:
#Find the Minimum Value in a 1D Array
import numpy as np
array = np.array([7,44,33, 45,77])
minimum_value = np.min(array)
print("Minimum value in the array:", minimum_value)

"""#TASK : 3"""

#ARGUMENT FUNCTION:
#Given a NumPy array r, determine the index of its maximum value using the appropriate
#NumPy function.
import numpy as np
r = np.array([7,44,3, 4,77,99])
max_index = np.argmax(r)
print("Index of maximum value in array r:", max_index)

#SLICING:
#Given a NumPy array a, assign the value 1000 to the first five elements using slicing.
import numpy as np
a = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
a[:5] = 1000
print("Sliced and modified array:",a)

#INDEXING
#Create a 3x3 NumPy array named mat with the following structure
import numpy as np
mat = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print("3x3 NumPy array mat:\n", mat)

#ARITHMETIC OPERATORS
#Create a one-dimensional NumPy array named c containing integers from 1 to 10
#(inclusive).
# And then perform element wise Addition, Subtraction, Multiplication and Division of the
#array with itself
import numpy as np
c = np.arange(1,11)
addition = c + c
subtraction = c - c
multiplication = c * c
division = c / c
print(c)
print("Addition:", addition)
print("Subtraction:", subtraction)
print("Multiplication:", multiplication)
print("Division:", division)

#UNIVERSAL ARRAY:
#ELEMENT-WISE ADDITION OF TWO ARRAY:
arr1 = np.array([1, 2, 3])
arr2 = np.array([4, 5, 6])
print("Element-wise Addition:", np.add(arr1, arr2))

#APPLYING TRIGONOMETRIC FUNCTION:
#Apply the sine and cosine to an array of angles.
angles = np.array([0, np.pi/2, np.pi])
sine_values = np.sin(angles)
cosine_values = np.cos(angles)
print("Sine values:", sine_values)
print("Cosine values:", cosine_values)

#EXPONENTIATION OF ARRAY ELEMENTS:
#Raise each element of a NumPy array to a specified power
arr = np.array([1, 2, 3, 4,7])
power = 2
result = np.power(arr, power)
print("Exponentiation result:", result)

#CALCULATING THE SQUARE ROOT OF ELEMENTS:
#Compute the square root of each element in a NumPy array
sqrt_arr = np.array([4, 9, 16, 25])
print("Square Roots:", np.sqrt(sqrt_arr))

#MATRIX MULTIPLICATION:
#Perform element-wise multiplication of a 3x3 NumPy array mat with itself.
mat = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
result = np.multiply(mat, mat)
print("Element-wise Multiplication:\n", result)