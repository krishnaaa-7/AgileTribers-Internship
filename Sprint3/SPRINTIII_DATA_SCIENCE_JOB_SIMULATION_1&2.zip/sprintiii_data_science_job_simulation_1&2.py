

#DATA SCIENCE JOB SIMULATION 1


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

# === TASK 1: Descriptive Analytics and Preprocessing ===

# Load dataset
file_path = "/content/drive/MyDrive/sales_data_with_discounts.xlsx"
data = pd.read_excel(file_path)
df = pd.DataFrame(data)
print("File loaded successfully")

# 1. Descriptive Analytics for Numerical Columns
numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()

# Basic statistics
desc_stats = df[numerical_cols].agg(['mean', 'median', 'std', lambda x: x.mode().iloc[0]])
desc_stats.rename(index={"<lambda_0>": "mode"}, inplace=True)
print("Descriptive Statistics:\n", desc_stats)

# 2. Data Visualization
# Histograms
for col in numerical_cols:
    plt.figure(figsize=(6,4))
    sns.histplot(df[col], kde=True)
    plt.title(f"Histogram of {col}")
    plt.show()

# Box Plots
for col in numerical_cols:
    plt.figure(figsize=(6,4))
    sns.boxplot(x=df[col])
    plt.title(f"Boxplot of {col}")
    plt.show()

# Bar Charts for Categorical Columns
categorical_cols = df.select_dtypes(include='object').columns.tolist()
for col in categorical_cols:
    plt.figure(figsize=(6,4))
    df[col].value_counts().plot(kind='bar')
    plt.title(f"Bar Chart of {col}")
    plt.ylabel('Count')
    plt.show()

# 3. Standardization of Numerical Variables (Z-score)
df_standardized = df.copy()
for col in numerical_cols:
    mean = df[col].mean()
    std = df[col].std()
    df_standardized[col] = (df[col] - mean) / std

print("\nStandardized Numerical Columns (first 5 rows):\n", df_standardized[numerical_cols].head())

# 4. One-hot Encoding for Categorical Columns
df_encoded = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
print("\nEncoded DataFrame (first 5 rows):\n", df_encoded.head())

# === TASK 2: One-Sample T-Test ===
battery_lives = [5.1, 4.9, 5.3, 5.0, 4.7, 5.2, 4.8, 5.1, 5.0, 4.9, 5.2, 4.6]
claimed_mean = 5.5
sample_mean = np.mean(battery_lives)
sample_std = np.std(battery_lives, ddof=1)
n = len(battery_lives)
t_statistic = (sample_mean - claimed_mean) / (sample_std / np.sqrt(n))

# Critical value for one-tailed t-test at alpha=0.05, df=11
t_critical = stats.t.ppf(0.05, df=n-1)

print(f"\nOne-Sample T-Test:")
print(f"Sample Mean = {sample_mean:.2f}")
print(f"T-Statistic = {t_statistic:.4f}")
print(f"Critical T-Value = {t_critical:.4f}")

# Decision
if t_statistic < t_critical:
    print("Reject the null hypothesis: Evidence supports the analyst’s claim.")
else:
    print("Fail to reject the null hypothesis: Not enough evidence against the claim.")

#DATA SCIENCE JOB SIMULATON 2

import numpy as np
from scipy.stats import ttest_rel

# Typing speed data before and after training
before_training = np.array([52, 47, 58, 43, 50, 46, 49, 53, 48, 51])
after_training = np.array([56, 50, 60, 45, 54, 48, 53, 56, 51, 55])

# Compute the differences
differences = before_training - after_training
mean_difference = np.mean(differences)

# Perform two-tailed paired t-test
t_statistic, p_value_two_tailed = ttest_rel(before_training, after_training)

# Convert to one-tailed p-value
p_value_one_tailed = p_value_two_tailed / 2

# Output results
print(f"Mean difference (Before - After): {mean_difference:.2f}")
print(f"T-statistic: {t_statistic:.4f}")
print(f"One-tailed p-value: {p_value_one_tailed:.4f}")

# Hypothesis testing decision at α = 0.05
alpha = 0.05
if p_value_one_tailed < alpha and mean_difference < 0:
    print("Reject the null hypothesis: Training significantly improved typing speed.")
else:
    print("Fail to reject the null hypothesis: No significant evidence that training improved speed.")







