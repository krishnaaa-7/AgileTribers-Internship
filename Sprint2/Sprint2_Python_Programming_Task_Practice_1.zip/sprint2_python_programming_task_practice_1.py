

#Task 1 : Using the return Statement
def cube(n):
  return n**3
print(cube(7))

#Task 2 : Using break in a Loop

while True:
  num = int(input("Enter a number: "))
  if num < 0:
    break
  print(cube(num))

#Task 3 : Using continue in a Loop
for i in range(1, 21):
    if i % 2 != 0:
        continue
    print(i)

#Task 4 : Using break and continue in a Loop

total = 0

while True:
    num = int(input("Enter a number: "))
    if num < 0:
        continue
    if num == 0:
        break
    total += num

print("Sum of positive numbers:", total)

#Task 5 : Local Scope in Functions Python Programming Task Practice - 1 1
def square(num):
    local_var = num ** 2
    print("Square:", local_var)

square(7)

#Task 6 : Modifying a Global Variable Inside a Function
counter = 0
def increment_counter():
    global counter
    counter += 1
    print("Counter:", counter)

increment_counter()
increment_counter()

#Task 7 : Demonstrating Local and Global Scope
x = 10  # Global variable

def modify_x():
    global x
    x += 5
    print("Inside function, x:", x)

def local_scope():
    y = 20  # Local variable
    print("Inside function, y:", y)

modify_x()
print("Outside function, x:", x)

# local_scope()
# print(y)  # Uncomment to see error, y is not accessible outside

#Task 8 : Working with Tuples in Python
fruits = ("apple", "banana", "cherry")
print(fruits[1])


fruits_list = list(fruits)
fruits_list[1] = "orange"
fruits = tuple(fruits_list)
print(fruits)

#Task 9 : Working with Sets in Python
set1={1,2,3,4,5}
set2={4,5,6,7,8}
print(set1.union(set2))
print(set1.intersection(set2))
print(set1.difference(set2))
print(set2.difference(set1))
print(set1.symmetric_difference(set2))
set1.add(10)
set2.discard(6)
print("Updated Set1:", set1)
print("Updated Set2:", set2)

num = 3
print(f"Is {num} in set1?", num in set1)

#Task 10 : Tuple and Set Operations
my_tuple = (10, 20, 30, 40, 50)
print("Third element:", my_tuple[2])

my_set = set(my_tuple)
my_set.add(70)
print("Updated Set:", my_set)

#Task 11 : List to Set Conversion & Basic Set Operations
list=[1,2,2,3,3,3,4,4,4,5,6,6,7,7,7,7,7,]
unique_list=set(list)
print("unique elements:",unique_list)
print("length of unique elements:",len(unique_list))
predefined_set = {3, 4, 5, 6, 7}
print("Intersection:", unique_list & predefined_set)
print("Union:", unique_list | predefined_set)
print("Difference:", unique_list - predefined_set)
print("Symmetric Difference:", unique_list ^ predefined_set)

#Task 12 : Working with Tuples, Sets, and Lists
num_list = [10, 20, 30, 40, 50]
print("List:", num_list)
num_list.append(60)
print("Updated List:", num_list)

num_tuple = tuple(num_list)
print("Tuple:", num_tuple)

num_set = set(num_tuple)
print("Set:", num_set)