

#Advanced Python Exception Handling & String Formatting Tasks


#Task 1 : Handling ZeroDivisionError
def safe_divide(a, b):
  try:
      return a/b
  except ZeroDivisionError:
          return "Error: Division by zero is not allowed."

print(safe_divide(10, 7))
print(safe_divide(10, 0))
print(safe_divide(10,9))

#Task 2 : Handling Multiple Exceptions
def divide_numbers():
  try:
    num=float(input("Enter the number"))
    divisor=input("Enter a divisor (as a string):")
    divisor=int(divisor)
    result=num/divisor
    return result
  except ValueError:
    return "Error: Invalid input. Please enter numeric values."
  except ZeroDivisionError:
    return "Error: Division by zero is not allowed."

print(divide_numbers())

#Task 3 : Using Try-Except-Finally
def read_file():
  try:
    file=open("data.txt","r")
    print(file.read())
  except FileNotFoundError:
    print("Error:File not found")
  finally:
    try:
      file.close()
    except NameError:
      pass

read_file()

#Task 4 : Custom Exception for Age Validation
class AgeError(Exception):
  pass

def check_age():
  try:
    age=int(input("Enter your age:" ))
    if age<18:
      raise AgeError("Age must be 18 or older.")
      return "Age is valid"
  except AgeError as e:
    return f"Error: {e}"
print(check_age())

#Task 5 : Nested Try-Except Blocks
def nested_try_except():
  try:
    num1=int(input("Enter the first number: "))
    num2=int(input("Enter the second number: "))
    try:
      result = num1/num2
    except ZeroDivisionError:
      return "Error: Division by zero is not allowed."
    else:
      return "operation successful:"+str(result)
  except ValueError:
    return "Error: Invalid input. Please enter numeric values."

print(nested_try_except())

#Task 6 : Raising Exceptions Manually
def validate_password(password):
    if len(password) < 8 or not any(char.isdigit() for char in password) or not any(char.isalpha() for char in password):
        raise ValueError("Password must be at least 8 characters long and contain both letters and numbers.")

# Example usage
try:
    validate_password("1234abc")
except ValueError as e:
    print(e)

#Task 7 : Exception Handling with Logging
import logging
def safe_divide(a,b):
  try:
    return a/b
  except ZeroDivisionError as e:
    logging.error("ZeroDivisionError:"+str(e))
    return "Error: Division by zero is not allowed."

print(safe_divide(10, 0))

#Task 8 : Exception Handling in Nested Functions
def inner_function():
  return 10/0

def outer_function():
  try:
    return inner_function()
  except ZeroDivisionError as e:
    return "Error: Division by zero is not allowed."

print(outer_function())

#Task 9 : Exception Handling for File Processing
def read_file(filename):
  try:
    with open(filename, 'r') as file:
      return file.read()
  except FileNotFoundError:
    return "Error: File not found."

print(read_file("data.txt"))

#Task 10 : Using Else with Try-Except
try:
  num= int(input("Enter a number: "))
except ValueError:
  print("Error: Invalid input. Please enter a numeric value.")
else:
  print("You entered:", num)

#Task 11 : Format Strings with f-strings
name = input("Enter your name: ")
age = int(input("Enter your age: "))
print(f"Hello, {name}! You are {age} years old.")

#Task 12 : Formatting Decimal Places
def format_float(value):
   return "{:.2f}".format(value), f"{value:.2f}"

print(format_float(12.5789))

#Task 13 : Aligning Text in String Formatting

items = {"Apple": 1.25, "Banana": 0.75, "Cherry": 2.50}
for item, price in items.items():
    print(item.ljust(10) + str(price).rjust(5))

#Task 14 : Dynamic String Formatting Using Dictionaries
person = {"name": "John", "age": 30, "city": "New York"}
print("{name} is {age} years old and lives in {city}.".format(**person))

#Task 15 : Formatting Large Numbers

def format_large_number(number):
    return "{:,}".format(number)

print(format_large_number(1000000))

#Task 16 : Combining String Formatting and Exception Handling
def validate_password(password):
    try:
        if len(password) < 8:
            raise ValueError(f"Error: The password '{password}' is too short. It must be at least 8 characters long.")
        if not any(char.isdigit() for char in password):
            raise ValueError(f"Error: The password '{password}' must contain at least one number.")
        if not any(char.isalpha() for char in password):
            raise ValueError(f"Error: The password '{password}' must contain at least one letter.")
        return "Password is valid."
    except ValueError as e:
        return str(e)

# Example usage
print(validate_password("123"))
print(validate_password("abcdefgh"))
print(validate_password("12345678"))
print(validate_password("abc12345"))

#Task 17 : Formatting Date and Time
from datetime import datetime

now = datetime.now()

print(f"Today is {now.strftime('%B %d, %Y')}, and the time is {now.strftime('%I:%M %p')}")

#Task 18 : Formatting Multi-Line Strings

user_details="""Name: sunny
Age: 20
Mail:sunny777@gmail.com"""
print(user_details)

#Task 19 : Creating and Writing to a File
def create_file():
    with open("students.txt", "w") as file:
        file.write("Alice\n")
        file.write("Bob\n")
        file.write("sunny\n")
    print("✅ 'students.txt' has been created and student names have been written.")
create_file()

#Task 20 : Reading and Appending to a File
def read_and_append(filename, text):
  with open(filename,"a+") as file:
    file.write("\n" + text)
    file.seek(0) # Corrected the indentation here
    print(file.read())

# Example usage
read_and_append("students.txt", "New Student:kiran")