

#Job Simulation : Student CourseManagement System

courses_available =("Python", "Data Science", "Web Development", "AI & ML")
students_enrolled = {} # initialize students_enrolled as a dictionary

def add_student():
  try:
    student_id=int(input("Enter student ID:"))
    student_name=input("Enter student name:")
    student_age=int(input("Enter student age:"))
    course=input("Enter course name:")
    if course not in courses_available:
      print("Invalid Course.Please select available one.")
    # Moved the following lines inside the 'if' block to ensure they execute only for valid courses
    Total_fees = int(input("Enter total fees:"))
    Paid_fee = int(input("Enter paid fee:"))
    Balance_amount = Total_fees - Paid_fee

    # Using students_enrolled instead of students
    students_enrolled[student_id] = {
        "Student_Name": student_name,
        "Student_Age": student_age,
        "Course": course,
        "Total_fees": Total_fees,
        "Paid_fee": Paid_fee,
        "Balance_amount": Balance_amount
    }

    with open("students.txt", "a") as file:
        file.write(f"{student_id},{student_name},{student_age},{course},{Total_fees},{Paid_fee},{Balance_amount}\n")
    print("Student added successfully.")
  except ValueError:
    print("Invalid input. Please enter valid values.")

# view_student function is now outside the except block of add_student
def view_student():
  student_id=int(input("Enter Student_id to view details:"))
  try:
    with open("students.txt","r") as file:
      print("---\n Students records---")
      for line in file:
        student_id, student_name, student_age, course, Total_fees, Paid_fee, Balance_amount = line.strip().split(",")
        print(f"Student ID: {student_id}, Student Name: {student_name}, Student Age: {student_age}, Course: {course}, Total Fees: ₹{Total_fees}, Paid Fee: ₹{Paid_fee}, Balance Amount: ₹{Balance_amount}")
  except FileNotFoundError:
    print("No records found out yet!!!")

def delete_student():
    student_id = input("Enter Student ID to delete: ") #add student_id variable
    try:
        with open("students.txt", "r") as f:
            lines = f.readlines()

        with open("students.txt", "w") as f:
            found = False
            for line in lines:
                sid = line.strip().split(",")[0]
                if sid != student_id: #Change sid_to_delete to student_id
                    f.write(line)
                else:
                    found = True

        if found:
            print(f"Student ID {student_id} deleted successfully.") #Change sid_to_delete to student_id
        else:
            print("Student ID not found.")
    except FileNotFoundError:
        print("No student records found.")


# generate_fee_receipt function is now outside the except block of view_student
def generate_fee_receipt():
  student_id=int(input("Enter Student_id to generate fee receipt:"))
  try:
    with open("students.txt","r") as file:
      for line in file:
        student_id, student_name, student_age, course, Total_fees, Paid_fee, Balance_amount = line.strip().split(",")
        # Assuming Balance_amount is the balance to be checked
        if int(Balance_amount) > 0:
            print(f"Name: {student_name} | Balance: ₹{Balance_amount}")
  except FileNotFoundError:
    print("No student records to generate fee recipt.")

# main function is now outside the except block of generate_fee_receipt
def main():
  while True:
    print("\n1 Add Student\n2 View Student\n3 Delete Student\n4 Generate Fee Receipt\n5 Exit")
    choice=input("Enter your choice:")

    if choice == "1":
      add_student()
    elif choice == "2":
      view_student()
    elif choice == "3":
      delete_student()
    elif choice == "4":
      generate_fee_receipt() # Calling generate_fee_receipt function
    elif choice == "5":
      break # Exit the loop if choice is 4
    else:
      print("Invalid choice. Please enter a valid option.")

# Calling the main function to start the program
if __name__ == "__main__":
    main()