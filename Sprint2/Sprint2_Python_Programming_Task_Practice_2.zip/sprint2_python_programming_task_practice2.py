

#Task 1 : Basic Dictionary Operations
Person = { 'Name':"Alice",'Age':25,'City':"Newyork"}
print(Person)
Person['Email']="alice@gmail.com"
Person['Age']=26
del Person['City']
print("Updated Dictionary:",Person)

#Task 2 : Accessing and Modifying Dictionary Values
fruits = {'apple': 10, 'banana': 5, 'cherry': 15}
print("Banana Quantity:",fruits['banana'])
fruits['Orange']=8
fruits['apple'] +=5
del fruits['cherry']
print("Updated Dictionary:",fruits)

#Task 3 : Counting Word Frequency
sentence = input("Enter a sentence: ")
words = sentence.split()
word_frequency = {}
for word in words:
    if word in word_frequency:
        word_frequency[word] += 1
    else:
        word_frequency[word] = 1
print("Word Frequency:",word_frequency)

#Task 4 : Merging Two Dictionaries
def merge_dicts(dict1, dict2):
    merged = dict1.copy()
    for key, value in dict2.items():
        merged[key] = merged.get(key, 0) + value
    return merged

dict1 = {'apple': 5, 'banana': 3, 'orange': 7}
dict2 = {'banana': 2, 'orange': 3, 'grape': 4}
print(merge_dicts(dict1, dict2))

#Task 5 : Nested Dictionary Processing
employees = {
 'E001': {'name': 'Alice', 'department': 'HR', 'salary': 50000},
 'E002': {'name': 'Bob', 'department': 'IT', 'salary': 60000},
 'E003': {'name': 'Charlie', 'department': 'Finance', 'salary': 55000}
}
def get_salary(employee_dict, emp_id):
    return employee_dict.get(emp_id, {}).get('salary', "Not found")

def increase_salary(employee_dict, percentage):
    for emp in employee_dict.values():
        emp['salary'] += emp['salary'] * (percentage / 100)

increase_salary(employees, 10)
print(employees)

#Task 6 : Sorting a Dictionary
marks = {'Alice': 85, 'Bob': 92, 'Charlie': 78, 'David': 90}
sorted_marks = dict(sorted(marks.items(), key=lambda item: item[1], reverse=True))
print(sorted_marks)

#Task 7 : Multiplication Table (1 to 10) using Nested Loops
for i in range(1, 11):
    for j in range(1, 11):
        print(i * j, end="\t")
    print()

#Task 8 : Transpose of a 2D Matrix
matrix= [[1,2,3],[4,5,6],[7,8,9]]
transpose = [[matrix[j][i] for j in range(len(matrix))] for i in range(len(matrix[0]))]
print(transpose)

#Task 9 : Counting Prime Numbers in a 2D Matrix
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

matrix = Matrix = [ [2, 4, 5], [7, 9, 11], [13, 16, 19] ]
prime_count = sum(is_prime(num) for row in matrix for num in row)
print("Total prime numbers:", prime_count)

#Task 10 : Spiral Order Matrix Traversal
def spiral_traversal(matrix):
    result = []

    while matrix:
        # Take the first row
        result += matrix.pop(0)

        # Take the last element of each remaining row
        if matrix and matrix[0]:
            for row in matrix:
                result.append(row.pop())

        # Take the last row in reverse order
        if matrix:
            result += matrix.pop()[::-1]

        # Take the first element of each remaining row (bottom to top)
        if matrix and matrix[0]:
            for row in matrix[::-1]:
                result.append(row.pop(0))

    return result

# Test case
matrix = [[1, 2, 3],
          [4, 5, 6],
          [7, 8, 9]]

print("Spiral Order:", spiral_traversal(matrix))

#Task 11 : Body Mass Index (BMI) Calculation
Weight = float(input("Enter your weight in kilograms: "))
Height = float(input("Enter your height in meters: "))
BMI = Weight / (Height ** 2)
if BMI < 18.5:
    Category = "Underweight"
    print("Underweight")
elif BMI < 25:
    Category = "Normal weight"
    print("Normal weight")
elif BMI < 30:
    Category = "Overweight"
    print("Overweight")
else:
    Category = "Obese"
    print("Obese")
print("Your BMI is:", BMI)

#Task 12 : Student Grade Classification
score = float(input("Enter your score: "))
if score >= 90:
    grade = "A"
elif score >= 80:
    grade = "B"
elif score >= 70:
    grade = "C"
elif score >= 60:
    grade = "D"

else:
    grade = "F"
print("Your grade is:", grade)

#Task 13 : Checking Palindromes in a 2D List

Matrix = [ ["madam", "apple", "racecar"], ["level", "hello", "civic"], ["world",
"deified", "rotor"] ]

for row in Matrix:
    for word in row:
        if word == word[::-1]:
            print(f"{word} is a palindrome")
        else:
            print(f"{word} is not a palindrome")

#Task 14 : Multiplication Table with Even Numbers Only
for i in range(1, 11):
    for j in range(1, 11):
        product = i * j
        if product % 2 == 0:
            print(product, end="\t")
    print()