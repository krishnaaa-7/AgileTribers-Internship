
import numpy as np
from scipy import stats

# ----------------------
# Task 1: One-Way ANOVA
# ----------------------

# Given data
group_a = [2, 3, 7, 2, 6]
group_b = [10, 8, 7, 5, 10]
group_c = [10, 13, 14, 13, 15]

# Step 1: Means
mean_a = np.mean(group_a)
mean_b = np.mean(group_b)
mean_c = np.mean(group_c)
overall_mean = np.mean(group_a + group_b + group_c)

# Step 2: Between-group variance (SSB)
ssb = 5 * ((mean_a - overall_mean)**2 + (mean_b - overall_mean)**2 + (mean_c - overall_mean)**2)

# Step 3: Within-group variance (SSW)
ssw = sum((x - mean_a)**2 for x in group_a) + \
      sum((x - mean_b)**2 for x in group_b) + \
      sum((x - mean_c)**2 for x in group_c)

# Step 4: Degrees of freedom
df_between = 3 - 1  # k - 1
df_within = 15 - 3  # N - k

# Step 5: Mean squares
ms_between = ssb / df_between
ms_within = ssw / df_within

# Step 6: F-statistic
f_statistic = ms_between / ms_within

# -------------------------

# -------------------------
# Print Results
# -------------------------

print("=== One-Way ANOVA ===")
print(f"Mean of Group A: {mean_a}")
print(f"Mean of Group B: {mean_b}")
print(f"Mean of Group C: {mean_c}")
print(f"Overall Mean: {overall_mean}")
print(f"SSB (Between Groups): {ssb}")
print(f"SSW (Within Groups): {ssw}")
print(f"Degrees of Freedom (Between): {df_between}")
print(f"Degrees of Freedom (Within): {df_within}")
print(f"MSB: {ms_between}")
print(f"MSW: {ms_within}")
print(f"F-Statistic: {f_statistic:.2f}")
print("Use F-table to compare F-statistic with critical value at df1=2 and df2=12")

# Task 2: Chi-Square Test
# -------------------------

# Observed and expected values
observed = [140, 160, 200]
expected = [150, 100, 250]

# Chi-Square calculation
chi_square_stat = sum((o - e)**2 / e for o, e in zip(observed, expected))

# Degrees of freedom
df_chi = len(observed) - 1


print("\n=== Chi-Square Test ===")
print(f"Observed: {observed}")
print(f"Expected: {expected}")
print(f"Chi-Square Statistic: {chi_square_stat:.2f}")
print(f"Degrees of Freedom: {df_chi}")
print("Use Chi-Square table to compare with critical value at df=2, alpha=0.05 (~5.99)")

!pip install fpdf