

#TASK 1: TWO SAMPLE T-TEST (Two-tailed)

import numpy as np
from scipy.stats import t, ttest_ind, norm

# Generate random samples using rvs()
np.random.seed(0)
class_A = np.random.normal(loc=70, scale=15, size=25)
class_B = np.random.normal(loc=74, scale=25, size=20)

# Calculate T-statistic and p-value
t_stat, p_value = ttest_ind(class_A, class_B)

# Degrees of freedom
df = len(class_A) + len(class_B) - 2

# T-critical value for 0.05 significance level (two-tailed)
alpha = 0.05
t_critical = t.ppf(1 - alpha/2, df)

print("Two Sample T-Test Results:")
print(f"T-statistic = {t_stat:.4f}")
print(f"T-critical (two-tailed, α=0.05, df={df}) = ±{t_critical:.4f}")
print(f"P-value = {p_value:.4f}")
if abs(t_stat) > t_critical:
    print("Conclusion: Reject null hypothesis (significant difference).")
else:
    print("Conclusion: Fail to reject null hypothesis (no significant difference).")

"""# TASK 2: PAIRED T-TEST"""

import numpy as np
from scipy.stats import t

# Before and After weights
before = np.array([185, 192, 206, 177, 225, 168, 256, 239, 199, 218])
after  = np.array([169, 187, 193, 176, 194, 171, 228, 217, 204, 195])

# Calculate differences
diff = after - before
d_bar = np.mean(diff)
sd = np.std(diff, ddof=1)
n = len(diff)
sd_bar = sd / np.sqrt(n)

# T-statistic
t_stat = d_bar / sd_bar

# Degrees of freedom
df = n - 1

# T-critical for 95% confidence (α = 0.05)
t_critical = t.ppf(1 - 0.025, df)

# Margin of Error
margin_error = t_critical * sd_bar

# Confidence Interval
lower_bound = d_bar - margin_error
upper_bound = d_bar + margin_error

print("\nPaired T-Test Results:")
print(f"Mean difference (d̄) = {d_bar:.4f}")
print(f"Standard deviation of difference = {sd:.4f}")
print(f"T-statistic = {t_stat:.4f}")
print(f"T-critical (two-tailed, α=0.05, df={df}) = ±{t_critical:.4f}")
print(f"Margin of Error = {margin_error:.4f}")
print(f"95% Confidence Interval: ({lower_bound:.4f}, {upper_bound:.4f})")
if abs(t_stat) > t_critical:
    print("Conclusion: Weight loss program is effective.")
else:
    print("Conclusion: Weight loss program is not effective.")



