

#TASK 1
import scipy.stats as stats

# Observed and Expected Frequencies
observed = [23, 16, 14, 19, 28]
expected = [20, 20, 20, 20, 20]

# Chi-square test statistic and p-value
chi2_stat, p_value = stats.chisquare(f_obs=observed, f_exp=expected)

# Critical value
df = len(observed) - 1  # degrees of freedom = 5 - 1 = 4
alpha = 0.05
chi2_critical = stats.chi2.ppf(q=1-alpha, df=df)

print("TASK 1 - CHI-SQUARE TEST")
print("Chi-Square Statistic:", chi2_stat)
print("Critical Value:", chi2_critical)
print("P-Value:", p_value)

if chi2_stat > chi2_critical:
    print("Result: Reject Null Hypothesis – Absences are not evenly distributed.")
else:
    print("Result: Fail to Reject Null Hypothesis – Absences are evenly distributed.")

#TASK 2
import numpy as np
from scipy.stats import ttest_rel

# Before and After cholesterol levels
before = np.array([210, 220, 195, 230, 225, 200, 215, 205, 190, 210, 220, 200, 230, 225, 215])
after  = np.array([198, 215, 185, 210, 205, 190, 200, 195, 180, 195, 210, 185, 220, 210, 200])

# Paired t-test
t_stat, p_value = ttest_rel(before, after)

# Critical value
alpha = 0.05
df = len(before) - 1
t_critical = stats.t.ppf(1 - alpha/2, df)


print("\nTASK 2 - PAIRED T-TEST")
print("T-Statistic:", t_stat)
print("T-Critical:", t_critical)
print("P-Value:", p_value)

if abs(t_stat) > t_critical:
    print("Result: Reject Null Hypothesis – Diet has a significant effect.")
else:
    print("Result: Fail to Reject Null Hypothesis – No significant effect.")

#TASK 3
# Example reaction time data (replace with actual values if given)
treatment_group = [200, 195, 180, 210, 190, 185]
control_group = [215, 220, 225, 210, 230, 218]

# Two-sample t-test
t_stat, p_value = stats.ttest_ind(treatment_group, control_group)


print("\nTASK 3 - TWO-SAMPLE T-TEST")
print("T-Statistic:", t_stat)
print("P-Value:", p_value)

if p_value < 0.05:
    print("Result: Reject Null Hypothesis – Significant difference between groups.")
else:
    print("Result: Fail to Reject Null Hypothesis – No significant difference.")

#TASK 4
# Test scores for three teaching methods
group_A = [75, 78, 72, 70, 73]  # Traditional Lecture
group_B = [85, 88, 84, 86, 87]  # Interactive Learning
group_C = [65, 68, 70, 66, 69]  # Online Modules

# One-way ANOVA
f_stat, p_value = stats.f_oneway(group_A, group_B, group_C)


print("\nTASK 4 - ONE-WAY ANOVA")
print("F-Statistic:", f_stat)
print("P-Value:", p_value)

if p_value < 0.05:
    print("Result: Reject Null Hypothesis – Teaching methods differ significantly.")
else:
    print("Result: Fail to Reject Null Hypothesis – No significant difference.")