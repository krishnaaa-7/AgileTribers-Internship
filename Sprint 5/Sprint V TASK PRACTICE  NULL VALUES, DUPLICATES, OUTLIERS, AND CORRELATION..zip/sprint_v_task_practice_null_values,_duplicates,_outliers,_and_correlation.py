import pandas as pd
import numpy as np

df=pd.read_excel('/content/drive/MyDrive/sample_data1.xlsx')

"""#Task 1 Identifying and Removing Missing Values

"""

#step1: checking for missing values
print(df.isnull().sum())

#step2:view rows with missing salary
print((df[df['Salary'].isnull()]))

#step3:view rows with missing qualification
print((df[df['Qualification'].isnull()]))

#step4:remove rows with missing values
df.dropna(inplace=True)

#step5:Re-check for any missing values
print(df.isnull().sum())

"""#Task 2 Handling missing values by Imputation"""

# Reload original data (if needed)
df=pd.read_excel('/content/drive/MyDrive/sample_data1.xlsx')

# Step 1: Detect Missing Values
print(df.isnull().sum())

# Step 2: Calculate Mean of Salary
salary_mean = df['Salary'].mean()
print("Mean Salary:", salary_mean)

# Step 3: Find Mode of Qualification
qualification_mode = df['Qualification'].mode()[0]
print("Mode of Qualification:", qualification_mode)

# Step 4: Fill Missing Values
df['Salary'].fillna(salary_mean, inplace=True)
df['Qualification'].fillna(qualification_mode, inplace=True)

# Step 5: Display Updated Dataset
print(df)

"""#Task3
###Identifying and Removing Duplicate Records
"""

# Step 1: Identify Duplicates
duplicates = df.duplicated()
print(duplicates)

# Step 2: Display Duplicate Records
print(df[df.duplicated()])

# Step 3: Remove Duplicates and Reset Index
df_no_duplicates = df.drop_duplicates().reset_index(drop=True)

# Step 4: Verify Cleaned Dataset
print(df_no_duplicates)