


import random
import string

def generate_password(length):
    chars = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choices(chars, k=length))
    return password

# Get user input
while True:
    try:
        length = int(input("Enter The Desired password length (min 7 ): "))
        if length < 7:
            print("Password length must be at least 7.")
        else:
            break
    except ValueError:
        print("Please enter a valid number.")

# Generate and display password
print("Generated Password:", generate_password(length))