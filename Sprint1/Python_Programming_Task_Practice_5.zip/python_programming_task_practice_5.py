

#1. Print Numbers from 1 to 10
#Write a Python program that prints numbers from 1 to 10 using a for loop.

for i in range(1,11):
  print(i)

#2. Print Even Numbers from 1 to 20
#Write a Python program that prints even numbers from 1 to 20 using a for loop.
for i in range(1,21):
  if i%2==0:
    print("Even Numbers from 1 to 20:",i)

#3. Print Odd Numbers from 1 to 20
#Write a Python program that prints odd numbers from 1 to 20 using a for loop.

for i in range(1,21):
  if i%2!=0:
    print("Even Numbers from 1 to 20:",i)

#4. Calculate the Factorial of a Number
#Write a Python program that calculates the factorial of a number using a for loop.
num = int(input("Enter a number: "))
fact = 1
for i in range(1, num + 1):
    fact *= i
print(f"Factorial of {num} is {fact}")

#5. Sum of Numbers from 1 to 100
#Write a Python program that calculates the sum of numbers from 1 to 100 using a for loop.
total=sum(range(1,101))
print("The sum of numbers from 1 to 100 is:",total)

#6. Calculate the Average of Numbers in a List
#Write a Python program that calculates the average of numbers in a list using a for loop.
numbers = [1, 2, 3, 4, 5,7,9,17]
total = 0
for num in numbers:
    total += num
average = total / len(numbers)
print("Average of numbers in the list:", average)

#7. Draw Patterns Using Nested Loops
#Write a Python program that uses nested loops to draw patterns (e.g., squares, triangles, diamonds).
n = 7
for i in range(1, n + 1):
    print('* ' * i)

#8. Print Numbers from 1 to 5
#Write a Python program that prints numbers from 1 to 5
for i in range(1,6):
  print(i)

#9. Print the First 10 Natural Numbers
#Write a Python program that prints the first 10 natural numbers using a for loop.

for i in range(1,11):
  print(i)

#10. Check if the First and Last Number of a List Are the Same
#Write a Python program to check if the first and last number of a list are the same.
numbers = [10, 20, 30, 40, 10]
if numbers[0] == numbers[-1]:
    print("True")
else:
    print("False")

#11. Print Numbers Divisible by 5
#Iterate through a given list of numbers and print only those divisible by 5.

numbers = [10, 20, 33, 46, 55,60,75,97,69,96,100]
for num in numbers:
    if num % 5 == 0:
        print(num)

#12. Check Whether a Character is a Vowel or Consonant
#Write a Python program to check whether a given character is a vowel or consonant

char = input("Enter a character: ").lower()
if char in 'aeiou':
    print("Vowel")
else:
    print("Consonant")

#13. Count Occurrences of Even and Odd Numbers Between 10 and 55
#Write a Python program that counts the occurrences of even and odd numbers in the range 10 to 55

evens = sum(1 for i in range(10, 56) if i % 2 == 0)
odds = sum(1 for i in range(10, 56) if i % 2 != 0)
print("Evens:", evens, '\n' "Odds:", odds)

#14. Print Numbers from 1 to 25, Excluding Multiples of 5
#Write a Python program that prints numbers from 1 to 25, excluding multiples of 5
for i in range(1,26):
  if i%5!=0:
    print(i)

#15. Calculate the Factorial of Each Element in a List
#Write a Python program that takes a list of numbers and calculates the factorial of each element using a for loop, then prints the results.
import math
numbers = [3, 4, 5, 6,7]
factorials = {num: math.factorial(num) for num in numbers}
print(factorials)

#16. Product or Sum of Two Integers
#Given two integers, return their product. If the product is greater than 500, return their sum instead
X=int(input("Enter the first number: "))
Y=int(input("Enter the second number: "))
if X*Y>500:
  print("Sum:",X+Y)
else:
  print("Product:",X*Y)

#17. Print the Greatest of Two Numbers
#Write a Python program to print the greater of two numbers.
X=int(input("Enter the first number: "))
Y=int(input("Enter the second number: "))
if X>Y:
  print("Greater number:",X)
else:
  print("Greater number:",Y)

#17
a, b = 10, 20
print(max(a, b))

#18
a, b, c = 10, 20, 30
print(max(a, b, c))

#18. Print the Greatest of Three Numbers
#Write a Python program to print the greatest of three numbers.
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))
num3 = float(input("Enter third number: "))

if num1 >= num2 and num1 >= num3:
    greatest = num1
    print("The greatest number is:", greatest)
elif num2 >= num1 and num2 >= num3:
    greatest = num2
    print("The greatest number is:", greatest)
else:
    greatest = num3
    print("The greatest number is:", greatest)

#19. Separate Positive and Negative Numbers from a List
#Write a Python program to separate positive and negative numbers from a list.

x = [23, 4, -6, 23, -9, 21, 3, -45, -8]
positive = [num for num in x if num > 0]
negative = [num for num in x if num < 0]
print("Positive:", positive)
print("Negative:", negative)

