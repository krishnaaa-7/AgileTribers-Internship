

#1.Product or Sum Condition
#Write a program that takes two integers as input and returns their product. If the product is greater than 500, return their sum instead
X= int(input("Enter 1st Number:"))
Y= int(input("Enter 2nd Number:"))
if X*Y<500:
  print(X*Y)
else:
  print(X+Y)

#2.Find the Greatest of Three Numbers
#Write a program to determine and print the largest number among three given numbers.
X= int(input("Enter 1st Number:"))
Y= int(input("Enter 2nd Number:"))
Z= int(input("Enter 3rd Number:"))
if X>Y and X>Z:
    print("X is the greatest number")
elif Y>X and Y>Z:
    print("Y is the greatest number")
else:
    print("Z 7is the greatest number")

#3.Remove Duplicate Items from a List
#Write a Python program to remove duplicate elements from a given list while maintaining the original order.
my_list = [1, 2, 3, 4, 2, 5, 6, 3, 7, 8, 1]
unique_list = []
print(my_list)
for item in my_list:
    if item not in unique_list:
        unique_list.append(item)
print(unique_list)

#4.Remove and Replace Elements in a List
#Given a list, remove all occurrences of a specific number and shift the remaining elements while keeping the original length.
nums = [3,2,2,3]
remove = 3
for i in nums:
    if i == remove:
        nums.remove(i)
print(nums)

#5. Check for Duplicates in a List
def has_duplicates(nums):
    return len(nums) != len(set(nums))

print(has_duplicates([1, 2, 3, 1]))
print(has_duplicates([1, 2, 3, 4]))

#6.Repeatedly Sum Digits Until a Single Digit is Obtained
#Implement a program that repeatedly adds all digits of an integer until only a single-digit number remains.
num = int(input("Enter a number:"))

while num >= 10:
    # Convert the number to a string, iterate through each digit,
    # convert it back to an integer, and sum them up.
    num = sum(int(digit) for digit in str(num))

print(num)

#7. Duplicate Each Occurrence of Zero in a List
#Given a fi xed-length list, duplicate each occurrence of 0, shifting the remaining elements to the right. Ensure the list size remains unchanged.
def duplicate_zeros(arr):
    i = 0
    while i < len(arr):
        if arr[i] == 0:
            arr.insert(i, 0)
            arr.pop()
            i += 1
        i += 1
    return arr
print(duplicate_zeros([1, 0, 2, 3, 0, 4, 5, 0]))

#8.Find the Intersection of Two Lists
#Write a program that identifi es and returns the common elements between two given lists.
#○ Example Input: nums1 = [1,2,2,1], nums2 = [2,2]
#○ Example Output: [2]
X= [1,2,2,1,7,3]
Y=[2,2,3]
common_elements = list(set(X) & set(Y))
print(common_elements)