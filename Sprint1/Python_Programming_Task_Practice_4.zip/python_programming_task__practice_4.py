
#Hands-On Python Challenge

#1. Identify if a Number is Positive or Negative
#Write a Python program that takes a number as input and determines whether it is positive or negative.
NUM=float(input("Enter a number:"))
if NUM>0:
  print("The Entered Number Is Positive")
elif NUM==0:
  print("The Entered Number Is Zero,It Is Neither Positive Nor Negative")
else:
  print("The Entered Number Is Negative")

#2. Identify if a Number is Even or Odd
#Write a Python program that takes a number as input and checks whether it is even or odd.
X = int(input("Enter a number:"))
if X % 2 ==0:
  print("The entered number is even.")
else:
  print("The entered number is odd.")

#3. Calculate the Power of a Number
#Compute and display the result of raising the base to the exponent.

Base = int(input("Enter the base number: "))
Exponent = int(input("Enter the exponent: "))
Result = Base ** Exponent
print(f"{Base}^{Exponent} = {Result}")

#4. Compare Two Numbers
#Write a Python program that takes two numbers as input and determines which number is greater. If the numbers are equal, display using if-else statements.
X= int(input("Enter 1st Number:"))
Y= int(input("Enter 2nd Number:"))
if X>Y:
  print("1st Number Is Greater Than 2nd Number")
elif X<Y:
  print("2nd Number Is Greater Than 1st Number")

else:
    print("Both Numbers Are Equal")

#5. Determine if a Year is a Leap Year
#Write a Python program that takes a year as input and checks whether it is a leap year
#using conditional statements.
year = int(input("Enter a year: "))

if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
    print(f"{year} is a leap year.")
else:
    print(f"{year} is not a leap year.")

#6. Grade Calculator
#Write a Python program that takes a student's score as input and assigns a grade based on the following criteria:
StudentScore = float(input("Enter the student score: "))


if StudentScore >= 90:
    Grade = 'A'
elif StudentScore >= 80:
    Grade = 'B'
elif StudentScore >= 70:
    Grade = 'C'
elif StudentScore >= 60:
    Grade = 'D'
else:
    Grade = 'F'

print(f"The student  grade is: {Grade}")

#7. How Old Are You? (Age-Based Messages)
#Write a Python program that takes a person's age as input and displays a message based on their age category:
Age = int(input("Enter your age: "))

if Age < 16:
    print("You can't drive.")
elif Age <18:
    print("You can drive but you can't vote.")
elif Age <= 24:
    print("You can vote but not rent a car.")
else:
    print("You can do pretty much anything.")

#8. FizzBuzz Challenge
#Write a Python program that prints numbers from 1 to 100. However, for
for num in range(1, 101):
    if num % 3 == 0 and num % 5 == 0:
        print("FizzBuzz")
    elif num % 3 == 0:
        print("Fizz")
    elif num % 5 == 0:
        print("Buzz")
    else:
        print(num)

#9. Leap Year Checker
#Write a Python program that determines if a given year is a leap year.
year = int(input("Enter the year: "))
if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
    print(year, "is a leap year")
else:
    print(year, "is not a leap year")