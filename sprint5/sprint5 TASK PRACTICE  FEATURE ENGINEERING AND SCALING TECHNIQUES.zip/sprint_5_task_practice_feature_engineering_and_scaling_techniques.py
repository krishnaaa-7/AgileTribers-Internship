
#TASK1

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.DataFrame ({
    'ID': [1, 2, 3, 4, 5],
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva'],
    'Gender': ['Female', 'Male', 'Male', 'Male', 'Female'],
    'Profession': ['Developer', 'Manager', 'Assistant Manager', 'Team Lead', 'CEO'],
    'Salary': [50000, 80000, 45000, 70000, 150000],
    'Experience': [3, 10, 2, 6, 15]
})
print("Original DataFrame:")
print(data)
print("\n shape of the Dataframe:",data.shape)

data.drop(columns=['Name'],inplace=True)
print("DataFrame after dropping 'Name' column:")
print(data)

"""#TASK 2


"""

from sklearn.preprocessing import OneHotEncoder, OrdinalEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import make_pipeline

print("\nUnique Professions:", data['Profession'].unique())

# Define encoders
gender_encoder = make_pipeline(OneHotEncoder(sparse_output=False))
profession_encoder = make_pipeline(OrdinalEncoder(categories=[['Assistant Manager', 'Developer', 'Team Lead', 'Manager', 'CEO']]))

# Combine using ColumnTransformer
column_transformer = ColumnTransformer(
    transformers=[
        ('gender_ohe', gender_encoder, ['Gender']),
        ('profession_ord', profession_encoder, ['Profession'])
    ],
    remainder='passthrough'
)

transformed = column_transformer.fit_transform(data)
encoded_df = pd.DataFrame(transformed, columns=['Female', 'Male', 'Profession_Level', 'ID', 'Salary', 'Experience'])
print("\nTransformed DataFrame with Encoded Features:")
print(encoded_df)

"""#TASK 3"""

from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler

# Identify numerical columns
numerical_cols = data.select_dtypes(exclude=['object']).columns.tolist()
print("\nNumerical Columns:", numerical_cols)

# Initialize scalers
std_scaler = StandardScaler()
minmax_scaler = MinMaxScaler()
robust_scaler = RobustScaler()

"""#Task 4"""

# Apply StandardScaler
standard_scaled = std_scaler.fit_transform(data[numerical_cols])
standard_scaled_df = pd.DataFrame(standard_scaled, columns=[f"{col}_std" for col in numerical_cols])

# Combine with encoded categorical features
final_df_std = pd.concat([encoded_df[['Female', 'Male', 'Profession_Level']], standard_scaled_df], axis=1)
print("\nFinal DataFrame with Standard Scaled Features:")
print(final_df_std)

"""#Task 5"""

# Apply MinMaxScaler
minmax_scaled = minmax_scaler.fit_transform(data[numerical_cols])
minmax_scaled_df = pd.DataFrame(minmax_scaled, columns=[f"{col}_minmax" for col in numerical_cols])
print("\nMin-Max Scaled Numerical Features:")
print(minmax_scaled_df)

"""#Task 6"""

# Apply RobustScaler
robust_scaled = robust_scaler.fit_transform(data[numerical_cols])
robust_scaled_df = pd.DataFrame(robust_scaled, columns=[f"{col}_robust" for col in numerical_cols])
print("\nRobust Scaled Numerical Features:")
print(robust_scaled_df)